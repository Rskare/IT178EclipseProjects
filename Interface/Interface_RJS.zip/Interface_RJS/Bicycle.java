/*
* File name: Bicycle.java
*
* Programmer: Ryan Skare
* ULID: rskare
*
* Date: Oct 1, 2020
*
* Class: IT 178
* Lecture Section: 02
* Lecture Instructor: Tonya Pierce
*/
package program;

/**
 * <calculates the carbon footprint of a bicycle>
 *
 * @author Ryan Skare
 *
 */
public class Bicycle implements CarbonFootprint{
	public double getCarbonFootprint ()
	{
		return 0;
	}
	
	public String toString ()
	{
		return "Bicycle: ";
	}
}
